// Auto-generated. Do not edit!

// (in-package cleardrive_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FocModeOfOperation {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.mode_of_operation = null;
    }
    else {
      if (initObj.hasOwnProperty('mode_of_operation')) {
        this.mode_of_operation = initObj.mode_of_operation
      }
      else {
        this.mode_of_operation = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FocModeOfOperation
    // Serialize message field [mode_of_operation]
    bufferOffset = _serializer.uint8(obj.mode_of_operation, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FocModeOfOperation
    let len;
    let data = new FocModeOfOperation(null);
    // Deserialize message field [mode_of_operation]
    data.mode_of_operation = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cleardrive_msgs/FocModeOfOperation';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '009bdb9fe8bcd4adb0b6a56149645d4f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 DISABLE = 1
    uint8 FREEZE = 2
    uint8 JOINT_TORQUE = 3
    uint8 JOINT_VELOCITY = 4
    uint8 JOINT_POSITION_VELOCITY_TORQUE = 5
    
    uint8 mode_of_operation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FocModeOfOperation(null);
    if (msg.mode_of_operation !== undefined) {
      resolved.mode_of_operation = msg.mode_of_operation;
    }
    else {
      resolved.mode_of_operation = 0
    }

    return resolved;
    }
};

// Constants for message
FocModeOfOperation.Constants = {
  DISABLE: 1,
  FREEZE: 2,
  JOINT_TORQUE: 3,
  JOINT_VELOCITY: 4,
  JOINT_POSITION_VELOCITY_TORQUE: 5,
}

module.exports = FocModeOfOperation;
