// Auto-generated. Do not edit!

// (in-package cleardrive_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let FocCommand = require('./FocCommand.js');

//-----------------------------------------------------------

class FocCommands {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.names = null;
      this.commands = null;
    }
    else {
      if (initObj.hasOwnProperty('names')) {
        this.names = initObj.names
      }
      else {
        this.names = [];
      }
      if (initObj.hasOwnProperty('commands')) {
        this.commands = initObj.commands
      }
      else {
        this.commands = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FocCommands
    // Serialize message field [names]
    bufferOffset = _arraySerializer.string(obj.names, buffer, bufferOffset, null);
    // Serialize message field [commands]
    // Serialize the length for message field [commands]
    bufferOffset = _serializer.uint32(obj.commands.length, buffer, bufferOffset);
    obj.commands.forEach((val) => {
      bufferOffset = FocCommand.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FocCommands
    let len;
    let data = new FocCommands(null);
    // Deserialize message field [names]
    data.names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [commands]
    // Deserialize array length for message field [commands]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.commands = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.commands[i] = FocCommand.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.names.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += 25 * object.commands.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cleardrive_msgs/FocCommands';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fe355c7fd4598652ef0912143af4fbf1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string[] names
    
    FocCommand[] commands
    
    ================================================================================
    MSG: cleardrive_msgs/FocCommand
    FocModeOfOperation mode_of_operation
    
    float64 joint_position
    float64 joint_velocity
    float64 joint_torque
    
    ================================================================================
    MSG: cleardrive_msgs/FocModeOfOperation
    uint8 DISABLE = 1
    uint8 FREEZE = 2
    uint8 JOINT_TORQUE = 3
    uint8 JOINT_VELOCITY = 4
    uint8 JOINT_POSITION_VELOCITY_TORQUE = 5
    
    uint8 mode_of_operation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FocCommands(null);
    if (msg.names !== undefined) {
      resolved.names = msg.names;
    }
    else {
      resolved.names = []
    }

    if (msg.commands !== undefined) {
      resolved.commands = new Array(msg.commands.length);
      for (let i = 0; i < resolved.commands.length; ++i) {
        resolved.commands[i] = FocCommand.Resolve(msg.commands[i]);
      }
    }
    else {
      resolved.commands = []
    }

    return resolved;
    }
};

module.exports = FocCommands;
