//
// Created by qiayuan on 24-4-15.
//

#pragma once

#include <cstdint>

namespace mit_ecat {

struct TxPdo {
  uint64_t can0Measurement_[4];
  uint64_t can1Measurement_[4];
  uint8_t digitalInputs_;
  uint32_t statusword_;
} __attribute__((packed));

struct RxPdo {
  uint32_t controlword_;
  uint64_t can0Commnads_[4];
  uint64_t can1Commnads_[4];
  uint8_t digitalOutputs_;
} __attribute__((packed));

}  // namespace mit_ecat
