//
// Created by qiayuan on 24-4-15.
//

#pragma once

#include <cstdint>
#include <iostream>
#include <memory>
#include <unordered_map>

namespace mit_ecat {

enum class CanBus { CAN0 = 0, CAN1 = 1 };

static constexpr size_t motorNumEachBus = 4;

class MotorConfiguration {
 public:
  std::string name_;
  double positionMaxRad_;
  double velocityMaxRadPerSec_;
  double kpMaxNmPerRad_;
  double kdMaxNmPerRadPerSec_;
  double torqueMaxNm_;
};

class GpioConfiguration {
 public:
  std::string name_;
  uint16_t mode_;
};

class Configuration {
 public:
  std::unordered_map<uint8_t, MotorConfiguration> can0MotorConfigurations_;
  std::unordered_map<uint8_t, MotorConfiguration> can1MotorConfigurations_;
  std::unordered_map<uint8_t, GpioConfiguration> gpioConfigurations_;

  bool sanityCheck(bool silent = false) const;

  uint8_t getGpioModes() const;

  friend std::ostream& operator<<(std::ostream& os, const Configuration& configuration);
};

inline size_t getIndex(CanBus bus, size_t id) {
  return static_cast<uint16_t>(bus) * motorNumEachBus + id - 1;
}

}  // namespace mit_ecat
