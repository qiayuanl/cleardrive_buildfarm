// Auto-generated. Do not edit!

// (in-package cleardrive_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let FocReading = require('./FocReading.js');

//-----------------------------------------------------------

class FocReadings {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.names = null;
      this.readings = null;
    }
    else {
      if (initObj.hasOwnProperty('names')) {
        this.names = initObj.names
      }
      else {
        this.names = [];
      }
      if (initObj.hasOwnProperty('readings')) {
        this.readings = initObj.readings
      }
      else {
        this.readings = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FocReadings
    // Serialize message field [names]
    bufferOffset = _arraySerializer.string(obj.names, buffer, bufferOffset, null);
    // Serialize message field [readings]
    // Serialize the length for message field [readings]
    bufferOffset = _serializer.uint32(obj.readings.length, buffer, bufferOffset);
    obj.readings.forEach((val) => {
      bufferOffset = FocReading.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FocReadings
    let len;
    let data = new FocReadings(null);
    // Deserialize message field [names]
    data.names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [readings]
    // Deserialize array length for message field [readings]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.readings = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.readings[i] = FocReading.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.names.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += 46 * object.readings.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cleardrive_msgs/FocReadings';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0edb351051e31df0e1cfe1924f0ea0da';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string[] names
    
    FocReading[] readings
    
    ================================================================================
    MSG: cleardrive_msgs/FocReading
    time stamp
    
    FocDriveState  drive_state
    FocModeOfOperation mode_of_operation
    uint32 statusword
    
    float64 joint_position
    float64 joint_velocity
    float64 joint_torque
    
    float32 voltage
    float32 temperature
    
    ================================================================================
    MSG: cleardrive_msgs/FocDriveState
    uint8 START = 1
    uint8 STANDBY = 2
    uint8 OPERATE = 3
    uint8 CALIBRATE = 4
    uint8 ERROR = 5
    uint8 FATAL = 6
    
    uint8 drive_state
    
    ================================================================================
    MSG: cleardrive_msgs/FocModeOfOperation
    uint8 DISABLE = 1
    uint8 FREEZE = 2
    uint8 JOINT_TORQUE = 3
    uint8 JOINT_VELOCITY = 4
    uint8 JOINT_POSITION_VELOCITY_TORQUE = 5
    
    uint8 mode_of_operation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FocReadings(null);
    if (msg.names !== undefined) {
      resolved.names = msg.names;
    }
    else {
      resolved.names = []
    }

    if (msg.readings !== undefined) {
      resolved.readings = new Array(msg.readings.length);
      for (let i = 0; i < resolved.readings.length; ++i) {
        resolved.readings[i] = FocReading.Resolve(msg.readings[i]);
      }
    }
    else {
      resolved.readings = []
    }

    return resolved;
    }
};

module.exports = FocReadings;
