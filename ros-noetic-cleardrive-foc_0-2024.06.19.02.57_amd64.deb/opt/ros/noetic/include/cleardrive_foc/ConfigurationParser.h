//
// Created by qiayuan on 23-3-21.
//

#pragma once
#include <yaml-cpp/yaml.h>
#include <message_logger/message_logger.hpp>

#include "cleardrive_foc/Configuration.h"

namespace cleardrive {
namespace foc {

class ConfigurationParser {
 public:
  ConfigurationParser() = delete;

  explicit ConfigurationParser(const std::string& filename);

  explicit ConfigurationParser(const YAML::Node& configNode);

  Configuration getConfiguration() const { return configuration_; }

 private:
  void parseConfiguration(YAML::Node configNode);

  Configuration configuration_{};
};

}  // namespace foc
}  // namespace cleardrive
