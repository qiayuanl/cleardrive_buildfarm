
#pragma once

#include <ostream>

namespace cleardrive {

namespace foc {

enum class DriveState : uint8_t {
  Start = 1,
  Standby = 2,
  Operate = 3,
  Calibrate = 4,
  Error = 5,
  Fatal = 6,
  NA = 0,
};

uint8_t driveStateEnumToId(DriveState driveState);

DriveState driveStateIdToEnum(uint8_t driveState);

}  // namespace foc

}  // namespace cleardrive

std::ostream& operator<<(std::ostream& os, const cleardrive::foc::DriveState& driveState);
