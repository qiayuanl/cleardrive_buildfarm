//
// Created by qiayuan on 23-3-12.
//

#pragma once

#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>

#include "cleardrive_foc/DriveState.h"
#include "cleardrive_foc/ModeOfOperation.h"

namespace cleardrive {
namespace foc {

class Statusword {
 public:
  friend std::ostream& operator<<(std::ostream& os, const Statusword& statusword);

  uint32_t getRaw() const { return statusword_; }
  void setRaw(uint32_t raw);

  DriveState getDriveState() const { return driveState_; }
  void setDriveState(DriveState driveSate) { driveState_ = driveSate; }
  std::string getDriveStateString() const;

  ModeOfOperation getModeOfOperation() const { return modeOfOperation_; }
  void setModeOfOperation(ModeOfOperation modeOfOperation) { modeOfOperation_ = modeOfOperation; }
  std::string getModeOfOperationString() const;

  bool getCalibrationRunning() const { return calibrationRunning_; }
  bool getCalibrationDone() const { return calibrationDone_; }

 private:
  uint32_t statusword_{0};
  DriveState driveState_{DriveState::NA};
  ModeOfOperation modeOfOperation_{ModeOfOperation::NA};
  uint16_t drvFaultStatus_{0};
  bool calibrationRunning_{false}, calibrationDone_{false};

  bool fatalGateDriver_{false};
  bool fatalOverTemperature_{false};
  bool fatalMotorEncoder_{false};
  bool fatalCurrentSensor_{false};
  bool fatalCalibration_{false};

  bool errorOverTemperature_{false};
  bool errorPdoTimeout_{false};
};

}  // namespace foc

}  // namespace cleardrive
