// Auto-generated. Do not edit!

// (in-package cleardrive_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FocModeOfCalibration {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.mode_of_calibration = null;
    }
    else {
      if (initObj.hasOwnProperty('mode_of_calibration')) {
        this.mode_of_calibration = initObj.mode_of_calibration
      }
      else {
        this.mode_of_calibration = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FocModeOfCalibration
    // Serialize message field [mode_of_calibration]
    bufferOffset = _serializer.uint8(obj.mode_of_calibration, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FocModeOfCalibration
    let len;
    let data = new FocModeOfCalibration(null);
    // Deserialize message field [mode_of_calibration]
    data.mode_of_calibration = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cleardrive_msgs/FocModeOfCalibration';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b684286d6eca14e6a3b6b1c10682f8fb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8  PHASES = 0
    uint8  OFFSET_PHI_E = 1
    uint8  DIRECTION_JOINT = 2
    uint8  OFFSET_JOINT = 3
    uint8  IC_MU = 4
    uint8  IC_MU_LUT = 5
    
    uint8 mode_of_calibration
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FocModeOfCalibration(null);
    if (msg.mode_of_calibration !== undefined) {
      resolved.mode_of_calibration = msg.mode_of_calibration;
    }
    else {
      resolved.mode_of_calibration = 0
    }

    return resolved;
    }
};

// Constants for message
FocModeOfCalibration.Constants = {
  PHASES: 0,
  OFFSET_PHI_E: 1,
  DIRECTION_JOINT: 2,
  OFFSET_JOINT: 3,
  IC_MU: 4,
  IC_MU_LUT: 5,
}

module.exports = FocModeOfCalibration;
