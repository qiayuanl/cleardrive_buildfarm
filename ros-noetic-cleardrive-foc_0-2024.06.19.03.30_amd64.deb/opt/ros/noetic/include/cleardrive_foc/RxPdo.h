#pragma once

#include <cstdint>

namespace cleardrive {
namespace foc {

struct RxPdo {
  uint8_t controlword_ = 0;
  uint8_t modeOfOperation_ = 0;

  float desiredTorque_ = 0.0;
  float desiredPosition_ = 0.0;
  float desiredVelocity_ = 0.0;

} __attribute__((packed));

}  // namespace foc

}  // namespace cleardrive
