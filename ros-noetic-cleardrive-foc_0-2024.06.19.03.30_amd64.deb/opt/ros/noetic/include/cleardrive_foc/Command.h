//
// Created by qiayuan on 23-3-13.
//

#pragma once

#include <cstdint>
#include <iostream>
#include <string>

#include "cleardrive_foc/ModeOfOperation.h"

namespace cleardrive {
namespace foc {

class Command {
 public:
  Command() = default;
  Command(const Command& other);
  virtual ~Command() = default;

  Command& operator=(const Command& other) = default;

  void setJointPosition(double jointPosition) { jointPosition_ = jointPosition; }
  void setJointVelocity(double jointVelocity) { jointVelocity_ = jointVelocity; }
  void setJointTorque(double jointTorque) { jointTorque_ = jointTorque; }
  void setModeOfOperation(const ModeOfOperation modeOfOperation) { modeOfOperation_ = modeOfOperation; }

  double getJointPosition() const { return jointPosition_; }
  double getJointVelocity() const { return jointVelocity_; }
  double getJointTorque() const { return jointTorque_; }
  ModeOfOperation getModeOfOperation() const { return modeOfOperation_; }

  friend std::ostream& operator<<(std::ostream& os, Command& command);

 private:
  double jointPosition_{0};
  double jointVelocity_{0};
  double jointTorque_{0};

  ModeOfOperation modeOfOperation_{ModeOfOperation::NA};
};

}  // namespace foc
}  // namespace cleardrive
