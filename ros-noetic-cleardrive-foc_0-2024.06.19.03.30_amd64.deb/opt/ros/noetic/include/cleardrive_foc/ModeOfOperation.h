//
// Created by qiayuan on 23-3-13.
//

#pragma once

#include <ostream>

namespace cleardrive {
namespace foc {

enum class ModeOfOperation {
  Disable = 1,
  Freeze = 2,
  JointTorque = 3,
  JointVelocity = 4,
  JointPositionVelocityTorque = 5,
  NA = 0,
};

uint8_t modeOfOperationEnumToId(ModeOfOperation modeOfOperation);

ModeOfOperation modeOfOperationIdToEnum(uint8_t modeOfOperation);

}  // namespace foc
}  // namespace cleardrive

std::ostream& operator<<(std::ostream& os, const cleardrive::foc::ModeOfOperation& modeOfOperation);
