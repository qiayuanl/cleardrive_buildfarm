import os
import rospy
import rospkg

from python_qt_binding import loadUi
from python_qt_binding.QtWidgets import QWidget, QMenu, QShortcut

from cleardrive_msgs.srv import *
from cleardrive_msgs.msg import FocCommands

import rqt_cleardrive.cleardrive_util as util


class ClearDriveFocDetailsWidget(QWidget):

    def __init__(self, parent, context, index, msg):
        super(ClearDriveFocDetailsWidget, self).__init__()
        self._refresh_rate = 5  # With default value
        self._ns = '/cleardrive'

        ui_file = os.path.join(rospkg.RosPack().get_path('rqt_cleardrive'), 'resource', 'cleardrive_foc_details.ui')
        loadUi(ui_file, self)

        self._index = index
        self._readings_msg = msg

        self._drive_state_srv = rospy.ServiceProxy(self._ns + '/set_goal_drive_state',
                                                   cleardrive_msgs.srv.SetGoalDriveState, persistent=False)

        self.button_calibration.clicked.connect(self._on_button_calibration_pressed)
        self.button_operation.clicked.connect(self._on_button_operation_pressed)

        self._cmd_pub = rospy.Publisher(self._ns + '/commands', FocCommands, queue_size=1)

        self.slider_operation.valueChanged.connect(self._on_slider_operation_changed)
        self.combo_operation.currentIndexChanged.connect(self._on_slider_operation_changed)
        self.button_reset.clicked.connect(self._on_button_reset_pressed)

        self.combo_operation.setCurrentIndex(
            self._readings_msg.readings[self._index].mode_of_operation.mode_of_operation)

    def update_readings(self, msg):
        self._readings_msg = msg
        self._on_update_readings()

    def _get_name(self):
        return self._readings_msg.names[self._index]

    def _get_drive_state(self):
        return util.drive_state_to_string(self._readings_msg.readings[self._index].drive_state.drive_state)

    def _get_mode_of_operation(self):
        return util.mode_of_operation_to_string(
            self._readings_msg.readings[self._index].mode_of_operation.mode_of_operation)

    def _get_statusword(self):
        return self._readings_msg.readings[self._index].statusword

    def _get_calibration_done(self):
        statusword_ = self._get_statusword()
        return (statusword_ & (1 << 9)) != 0

    def _on_update_readings(self):
        self.label_name.setText(self._get_name())
        self.label_drive_state.setText(self._get_drive_state())
        self.label_mode_of_operation.setText(self._get_mode_of_operation())

        drive_state = self._get_drive_state()

        if drive_state == "Calibrate":
            self.button_operation.setEnabled(False)
            self.combo_operation.setEnabled(False)
            self.slider_operation.setEnabled(False)
            self.button_calibration.setText("Stop")
            if self._get_calibration_done():
                self._on_button_calibration_pressed()  # Automatically stop calibration
        else:
            self.button_operation.setEnabled(True)
            self.combo_operation.setEnabled(True)
            self.slider_operation.setEnabled(True)
            self.button_calibration.setText("Start")

        if drive_state == "Operate":
            self.button_calibration.setEnabled(False)
            self.combo_calibration.setEnabled(False)
            self.button_operation.setText("Stop")
        else:
            self.button_calibration.setEnabled(True)
            self.combo_calibration.setEnabled(True)
            self.button_operation.setText("Start")

    def _on_button_calibration_pressed(self):
        req = cleardrive_msgs.srv.SetGoalDriveStateRequest()
        req.name = self._get_name()
        if self.button_calibration.text() == "Start":
            req.drive_state.drive_state = cleardrive_msgs.msg.FocDriveState.CALIBRATE
            req.mode_of_calibration.mode_of_calibration = self.combo_calibration.currentIndex()
            self._drive_state_srv.call(req)
        else:
            req.drive_state.drive_state = cleardrive_msgs.msg.FocDriveState.STANDBY
            self._drive_state_srv.call(req)
        pass

    def _on_button_operation_pressed(self):
        req = cleardrive_msgs.srv.SetGoalDriveStateRequest()
        req.name = self._get_name()
        if self.button_operation.text() == "Start":
            req.drive_state.drive_state = cleardrive_msgs.msg.FocDriveState.OPERATE
            self._drive_state_srv.call(req)
            self._on_slider_operation_changed()
        else:
            req.drive_state.drive_state = cleardrive_msgs.msg.FocDriveState.STANDBY
            self._drive_state_srv.call(req)
        pass

    def _on_slider_operation_changed(self):
        value = (self.slider_operation.value() + 100) / 200.0 * (
                self.spinbox_max.value() - self.spinbox_min.value()) + self.spinbox_min.value()
        self.label_operation_value.setText("{:.2f}".format(value))

        cmd = cleardrive_msgs.msg.FocCommand()
        cmd.mode_of_operation.mode_of_operation = self.combo_operation.currentIndex()

        if cmd.mode_of_operation.mode_of_operation == cleardrive_msgs.msg.FocModeOfOperation.JOINT_TORQUE:
            cmd.joint_torque = value
            self.label_operation_value.setText(self.label_operation_value.text() + " Nm")
        elif cmd.mode_of_operation.mode_of_operation == cleardrive_msgs.msg.FocModeOfOperation.JOINT_VELOCITY:
            cmd.joint_velocity = value
            self.label_operation_value.setText(self.label_operation_value.text() + " rad/s")
        elif cmd.mode_of_operation.mode_of_operation == cleardrive_msgs.msg.FocModeOfOperation.JOINT_POSITION_VELOCITY_TORQUE:
            cmd.joint_position = value
            self.label_operation_value.setText(self.label_operation_value.text() + " rad")

        msg = cleardrive_msgs.msg.FocCommands()
        msg.names.append(self._get_name())
        msg.commands.append(cmd)
        self._cmd_pub.publish(msg)

    def _on_button_reset_pressed(self):
        self.slider_operation.setValue(
            -self.spinbox_min.value() / (self.spinbox_max.value() - self.spinbox_min.value()) * 200 - 100)
        self._on_slider_operation_changed()
        pass
