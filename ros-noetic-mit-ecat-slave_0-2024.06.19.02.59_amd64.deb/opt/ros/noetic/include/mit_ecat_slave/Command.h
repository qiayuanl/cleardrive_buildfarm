//
// Created by qiayuan on 24-4-15.
//

#pragma once

#include <cstdint>
#include <iostream>
#include <mutex>
#include <string>

#include "mit_ecat_slave/Configuration.h"

namespace mit_ecat {

class Command {
 public:
  Command() = default;
  Command(const Command& other);

  void configureCommand(const Configuration& configuration);

  Command& operator=(const Command& other);

  // Set (SI units)
  void setMotorTarget(CanBus bus, size_t id, double targetPosition, double targetVelocity, double kp, double kd, double targetTorque);
  void setDigitalOutput(uint8_t id, bool value);

  // Get (raw)
  uint64_t getMotorCommandRaw(CanBus bus, size_t id) const;
  uint8_t getDigitalOutputs() const;

  template <typename T>
  T toRaw(double value, double xMin, double xMax, int bits) const {
    double span = xMax - xMin;
    double offset = xMin;
    return static_cast<T>(((value - offset) * ((1 << bits) - 1) / span));
  }

 private:
  uint32_t controlWord_{0};
  double targetPosition_[motorNumEachBus * 2]{0};
  double targetVelocity_[motorNumEachBus * 2]{0};
  double targetKp_[motorNumEachBus * 2]{0};
  double targetKd_[motorNumEachBus * 2]{0};
  double targetTorque_[motorNumEachBus * 2]{0};
  MotorConfiguration motorConfigurations_[motorNumEachBus * 2];
  uint8_t digitalOutputs_{0};
};

}  // namespace mit_ecat
