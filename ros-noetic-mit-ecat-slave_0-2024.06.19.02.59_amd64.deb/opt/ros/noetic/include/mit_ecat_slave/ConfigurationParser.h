//
// Created by qiayuan on 24-4-15.
//

#pragma once

#include <yaml-cpp/yaml.h>
#include <message_logger/message_logger.hpp>

#include "mit_ecat_slave/Configuration.h"

namespace mit_ecat {

enum class MotorType { DM4310, DM4340, DM8009 };

class ConfigurationParser {
 public:
  ConfigurationParser() = delete;

  explicit ConfigurationParser(const std::string& filename);

  explicit ConfigurationParser(const YAML::Node& configNode);

  Configuration getConfiguration() const { return configuration_; }

 private:
  void parseConfiguration(YAML::Node configNode);

  static double getMaxPosition(MotorType motorType);
  static double getMaxVelocity(MotorType motorType);
  static double getMaxTorque(MotorType motorType);
  static double getMaxKp(MotorType motorType);
  static double getMaxKd(MotorType motorType);

  static MotorType getMotoTypeFromString(const std::string& motorTypeString);

  Configuration configuration_{};
};

}  // namespace mit_ecat
