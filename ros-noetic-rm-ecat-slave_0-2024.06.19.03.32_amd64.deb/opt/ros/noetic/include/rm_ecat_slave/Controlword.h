//
// Created by qiayuan on 23-5-14.
//

#pragma once

#include <cstdint>
#include <iostream>

namespace rm_ecat {

enum class Controlword : uint32_t {};

uint32_t controlwordToId(Controlword controlword);

}  // namespace rm_ecat
