//
// Created by qiayuan on 24-4-15.
//

#pragma once

#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>

#include "mit_ecat_slave/Configuration.h"

namespace mit_ecat {

class Statusword {
 public:
  friend std::ostream& operator<<(std::ostream& os, const Statusword& statusword);

  uint32_t getRaw() const { return statusword_; }
  void setRaw(uint32_t raw) { statusword_ = raw; }

  // Motor
  bool isOnline(CanBus bus, size_t id) const;

 private:
  uint32_t statusword_{0};
};

}  // namespace mit_ecat
