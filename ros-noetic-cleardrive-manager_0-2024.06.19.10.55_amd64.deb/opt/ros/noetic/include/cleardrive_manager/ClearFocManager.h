//
// Created by qiayuan on 23-4-10.
//

#pragma once

#include <cleardrive_foc/ClearFocSlave.h>
#include <ecat_manager/EcatSlaveManagerBase.h>

namespace cleardrive::foc {

class ClearFocManager : public ecat_manager::EcatSlaveManagerBase<ClearFocSlave> {
 public:
  // Setup and configuration
  using EcatSlaveManagerBase::EcatSlaveManagerBase;
  ecat_manager::EcatBusManager::EthercatSlaveType getSlaveType() const override {
    return ecat_manager::EcatBusManager::EthercatSlaveType::ClearFoc;
  }
  // Execution
  bool startup() override;

  // State Machine
  bool setGoalDriverStates(DriveState goalState, bool reachStates = false);
  void clearGoalDriverStates();
  //  bool allDevicesAreConnected() const;
  bool allDevicesAreInTheState(DriveState state) const;
  bool allDevicesAreInTheSameState(DriveState& state) const;
  bool allDevicesAreInTheMode(ModeOfOperation mode) const;
  bool allDevicesAreInTheSameMode(ModeOfOperation& mode) const;
  bool noDeviceIsInErrorState() const;
  bool noDeviceIsInFatalState() const;

  // Calibration
  bool calibrate(const std::string& deviceName, ModeOfCalibration mode);

  // Control
  void sendControlwords(Controlword controlword);
  void stageDisables();
  void stageFreezes();
  void stageZeroJointTorques();
};

}  // namespace cleardrive::foc
