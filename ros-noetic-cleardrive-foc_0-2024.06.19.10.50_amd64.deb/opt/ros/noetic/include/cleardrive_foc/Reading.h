//
// Created by qiayuan on 23-3-14.
//

#pragma once

#include <chrono>
#include <string>

#include "cleardrive_foc/Statusword.h"

namespace cleardrive {
namespace foc {

using ReadingTimePoint = std::chrono::time_point<std::chrono::high_resolution_clock>;

class Reading {
 public:
  const ReadingTimePoint& getStamp() const { return stamp_; }
  void setStamp(const ReadingTimePoint& stamp) { stamp_ = stamp; }
  const Statusword& getStatusword() const { return statusword_; }
  void setStatusword(const Statusword& statusword) { statusword_ = statusword; }

  double getJointPosition() const { return jointPosition_; }
  void setJointPosition(const double jointPosition) { jointPosition_ = jointPosition; }
  double getJointVelocity() const { return jointVelocity_; }
  void setJointVelocity(const double jointVelocity) { jointVelocity_ = jointVelocity; }
  double getJointTorque() const { return jointTorque_; }
  void setJointTorque(const double jointTorque) { jointTorque_ = jointTorque; }

  double getVoltage() const { return voltage_; }
  void setVoltage(const double voltage) { voltage_ = voltage; }
  double getTemperature() const { return temperature_; }
  void setTemperature(const double temperature) { temperature_ = temperature; }

  //  bool isValid() const;
  //
  //  virtual std::string asString(const std::string& prefix = "") const;

 protected:
  ReadingTimePoint stamp_;
  Statusword statusword_;

  double jointPosition_ = 0.0;
  double jointVelocity_ = 0.0;
  double jointTorque_ = 0.0;

  float voltage_ = 0.0;
  float temperature_ = 0.0;
};

}  // namespace foc
}  // namespace cleardrive
