//
// Created by qiayuan on 23-3-31.
//

#pragma once

#include <cstdint>

namespace cleardrive {

namespace foc {

enum class ModeOfCalibration {
  Phases = 0,
  OffsetPhiE = 1,
  PowerOn = 2,
  DirectionJoint = 3,
  OffsetJoint = 4,
  IcMu = 5,
  IcMuLut = 6,
};

uint8_t modeOfCalibrationEnumToId(ModeOfCalibration modeOfOperation);

ModeOfCalibration modeOfCalibrationIdToEnum(uint8_t modeOfOperation);

typedef struct {
  uint32_t mag_raw;
  uint8_t gx_m, voss_m, vosc_m, ph_m, phr_m, gx_n, voss_n, vosc_n, ph_n, phr_n;
  int8_t spo_base, spo[15];
  int32_t offset_lut[32];
} MuCalibrationResult;

typedef struct {
  uint8_t polePairs;
  uint8_t phaseOrder;
  int ezero;
  int offset_lut[128];
  float poweronAngle;
  int8_t directionJoint;
  float offsetMotor;
  MuCalibrationResult mu;
} __attribute__((packed)) CalibrationResult;

}  // namespace foc
}  // namespace cleardrive
