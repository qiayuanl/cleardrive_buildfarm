//
// Created by qiayuan on 23-4-6.
//

#pragma once
#include <cstdint>
#include <iostream>
#include <unordered_map>

#include "cleardrive_foc/ModeOfOperation.h"
#include "cleardrive_foc/Sdo.h"

namespace cleardrive {
namespace foc {

class Configuration {
 public:
  float motorTorqueConstant_;
  float motorCurrentPeak_, motorCurrentNominal_, motorTimePeak_;
  float motorTemperatureError_, motorTemperatureFatal_;
  float gearRatio_;
  float ema_cutoff_freq_;

  std::unordered_map<ModeOfOperation, PidParameters> modeAndPids_;

  ModeOfOperation errorBehavior_{ModeOfOperation::Disable};

  bool sanityCheck(bool silent = false) const;

 public:
  friend std::ostream& operator<<(std::ostream& os, const Configuration& configuration);
};

}  // namespace foc
}  // namespace cleardrive
