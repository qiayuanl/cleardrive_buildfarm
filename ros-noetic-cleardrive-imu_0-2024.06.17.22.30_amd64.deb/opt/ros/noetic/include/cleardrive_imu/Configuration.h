//
// Created by qiayuan on 23-3-21.
//

#pragma once
#include <cstdint>
#include <iostream>

#include "Sdo.h"

namespace cleardrive {
namespace imu {

class Configuration {
 public:
  uint8_t desiredTemperature_;
  uint8_t sampleRate_;
  PidParameters pidParameters_;

  bool sanityCheck(bool silent = false) const;

 public:
  friend std::ostream& operator<<(std::ostream& os, const Configuration& configuration);
};

}  // namespace imu
}  // namespace cleardrive
