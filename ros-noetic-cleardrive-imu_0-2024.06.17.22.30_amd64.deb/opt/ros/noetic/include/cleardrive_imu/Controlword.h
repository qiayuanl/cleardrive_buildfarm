#pragma once

#include <cstdint>
#include <iostream>

namespace cleardrive {

namespace imu {
enum class Controlword : uint8_t {
  DisableHeat = 1,
  EnableHeat = 2,
  NA = 0,
};

uint8_t controlwordToId(Controlword controlword);

}  // namespace imu

}  // namespace cleardrive
