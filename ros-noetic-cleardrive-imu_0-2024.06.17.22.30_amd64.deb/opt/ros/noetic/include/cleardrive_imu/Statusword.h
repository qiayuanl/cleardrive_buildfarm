//
// Created by qiayuan on 23-3-12.
//

#pragma once

#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>

namespace cleardrive {
namespace imu {

class Statusword {
 public:
  friend std::ostream& operator<<(std::ostream& os, const Statusword& statusword);

  uint8_t getRaw() const { return statusword_; }
  void setRaw(uint8_t raw) { statusword_ = raw; }

 private:
  uint32_t statusword_{0};

  bool warningUnableToHeat_{false};
  bool errorOverTemperature_{false};
  bool fatalSetup_{false};
};

}  // namespace imu

}  // namespace cleardrive
