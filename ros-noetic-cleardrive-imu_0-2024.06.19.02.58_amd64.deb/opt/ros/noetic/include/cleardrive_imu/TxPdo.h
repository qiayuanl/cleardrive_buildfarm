//
// Created by qiayuan on 23-3-12.
//

#pragma once

#include <cstdint>

namespace cleardrive {
namespace imu {

struct TxPdo {
  float temperature_;
  struct {
    float w_;
    float x_;
    float y_;
    float z_;
  } orientation_;
  struct {
    float x_;
    float y_;
    float z_;
  } linearAcceleration_;
  struct {
    float x_;
    float y_;
    float z_;
  } angularVelocity_;
  uint8_t statusword_;
} __attribute__((packed));

}  // namespace imu

}  // namespace cleardrive
