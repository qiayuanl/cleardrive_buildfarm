//
// Created by qiayuan on 23-3-19.
//
#pragma once

namespace cleardrive {
namespace imu {

struct PidParameters {
  float kp;
  float ki;
  float kd;
  float maxOut;
  float maxIOut;
} __attribute__((packed));

}  // namespace imu
}  // namespace cleardrive