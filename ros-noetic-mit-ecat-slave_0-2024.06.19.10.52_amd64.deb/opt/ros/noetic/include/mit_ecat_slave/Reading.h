//
// Created by qiayuan on 24-4-15.
//

#pragma once
#include <chrono>

#include <memory>
#include <string>
#include <vector>

#include "mit_ecat_slave/Configuration.h"
#include "mit_ecat_slave/Statusword.h"

namespace mit_ecat {
using ReadingTimePoint = std::chrono::time_point<std::chrono::high_resolution_clock>;

inline double getTime(ReadingTimePoint stamp) {
  return static_cast<double>(std::chrono::duration_cast<std::chrono::seconds>(stamp.time_since_epoch()).count()) +
         1e-9 * static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(stamp.time_since_epoch()).count() % 1000000000);
}

class Reading {
 public:
  void configureReading(const Configuration& configuration);

  const ReadingTimePoint& getStamp() const { return stamp_; }
  void setStamp(const ReadingTimePoint& stamp) { stamp_ = stamp; }
  const Statusword& getStatusword() const { return statusword_; }
  void setStatusword(const Statusword& statusword) { statusword_ = statusword; }

  std::vector<size_t> getEnabledMotorIds(CanBus bus) const;
  std::vector<uint8_t> getEnabledDigitalInputIds() const;
  /*!
   * raw get methods
   */
  std::string getMotorName(CanBus bus, size_t id) const;
  uint16_t getRawReading(CanBus bus, size_t id) const;

  /*!
   * SI units get methods
   */
  // Motors
  double getPosition(CanBus bus, size_t id) const;
  double getVelocity(CanBus bus, size_t id) const;
  double getTorque(CanBus bus, size_t id) const;
  double getTemperature(CanBus bus, size_t id) const;
  // Digital inputs
  bool getDigitalInput(uint8_t id) const;

  /*!
   * set methods (only raw)
   */
  // Motors
  void setRawReading(CanBus bus, size_t id, uint64_t data);
  // Digital inputs
  void setDigitalInputs(uint8_t value);

  template <typename T>
  double fromRaw(T value, double xMin, double xMax, int bits) const {
    double span = xMax - xMin;
    double offset = xMin;
    return ((double)value) * span / ((double)((1 << bits) - 1)) + offset;
  }

 protected:
  ReadingTimePoint stamp_;
  Statusword statusword_;

  // Motors
  std::string names_[motorNumEachBus * 2]{""};
  bool isMotorEnabled_[motorNumEachBus * 2]{false};
  uint64_t rawReadings_[motorNumEachBus * 2]{0};
  MotorConfiguration motorConfigurations_[motorNumEachBus * 2];

  // Digital inputs
  bool isDigitalInputEnabled_[8]{false};
  bool digitalInputs_[8]{false};
};

}  // namespace mit_ecat
