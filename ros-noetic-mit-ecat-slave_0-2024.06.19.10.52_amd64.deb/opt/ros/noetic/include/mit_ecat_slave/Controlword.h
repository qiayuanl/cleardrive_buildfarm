//
// Created by qiayuan on 24-4-15.
//

#pragma once

#include <cstdint>
#include <iostream>

namespace mit_ecat {

enum class Controlword : uint32_t {
  DisableToEnable = 1,
  EnableToDisable = 2,
  NA = 0,
};

uint32_t controlwordToId(Controlword controlword);

}  // namespace mit_ecat
