//
// Created by qiayuan on 23-3-12.
//

#pragma once

#include <cstdint>

namespace cleardrive {
namespace foc {

struct TxPdo {
  uint16_t measuredTemperature_ = 0;
  uint16_t measuredMotorVoltage_ = 0;
  float measuredJointPosition_ = 0.0;
  float measuredJointVelocity_ = 0.0;
  uint32_t statusword_ = 0;
  float measuredJointTorque_ = 0.0;

} __attribute__((packed));

}  // namespace foc

}  // namespace cleardrive
