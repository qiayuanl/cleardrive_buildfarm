#pragma once

#include <cstdint>
#include <iostream>

namespace cleardrive {

namespace foc {
enum class Controlword : uint8_t {
  StandbyToOperate = 1,
  OperateToStandby = 2,
  StandbyToCalibrate = 3,
  CalibrateToStandby = 4,
  OperateToError = 5,
  ErrorToOperate = 6,
  ErrorToStandby = 7,
  FatalToStandby = 9,
  NA = 0,
};

uint8_t controlwordToId(Controlword controlword);

}  // namespace foc

}  // namespace cleardrive
