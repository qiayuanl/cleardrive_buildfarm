//
// Created by qiayuan on 23-3-12.
//

#pragma once

#include "cleardrive_foc/Command.h"
#include "cleardrive_foc/Configuration.h"
#include "cleardrive_foc/Controlword.h"
#include "cleardrive_foc/DriveState.h"
#include "cleardrive_foc/ModeOfCalibration.h"
#include "cleardrive_foc/Reading.h"

#include <soem_interface_rsl/EthercatSlaveBase.hpp>
#include <soem_interface_rsl/common/EthercatTypes.hpp>

#include <yaml-cpp/yaml.h>

#include <condition_variable>

namespace cleardrive {

namespace foc {

class ClearFocSlave : public soem_interface_rsl::EthercatSlaveBase {
 public:
  using SharedPtr = std::shared_ptr<ClearFocSlave>;

  static SharedPtr deviceFromFile(const std::string& configFile, const std::string& name, uint32_t address);
  void setTimeStep(double timeStep) { timeStep_ = timeStep; }
  void setState(soem_interface_rsl::ETHERCAT_SM_STATE state);
  bool waitForState(soem_interface_rsl::ETHERCAT_SM_STATE state, unsigned int maxRetries = 40);

  // Constructor
  ClearFocSlave() = default;
  ClearFocSlave(const std::string& name, uint32_t address);
  ~ClearFocSlave() override = default;

  // pure virtual overwrites
  std::string getName() const override { return name_; }
  bool startup() override;
  void shutdown() override;
  void updateWrite() override;
  void updateRead() override;
  PdoInfo getCurrentPdoInfo() const override { return pdoInfo_; }

  // Control
  void stageDisable();
  void stageFreeze();
  void stageZeroJointTorque();
  void stageCommand(const Command& command);

  // Readings
  Reading getReading() const;
  void getReading(Reading& reading) const;

  // Configuration
  bool loadConfigFile(const std::string& fileName);
  bool loadConfigNode(const YAML::Node& configNode);
  bool loadConfiguration(const Configuration& configuration);
  Configuration getConfiguration() const;

  // SDO
  bool getStatuswordViaSdo(Statusword& statusword);
  bool setControlwordViaSdo(Controlword& controlword);
  bool setDriveStateViaSdo(const DriveState& requestedDriveState);
  bool setModeOfCalibrationViaSdo(const ModeOfCalibration& modeOfCalibration);
  bool setGainsCurrent(float kp, float ki);
  bool setGainsVelocity(float kp, float kd);
  bool setGainsPositionVelocityTorque(float kp, float kd);

  // PDO
  bool setDriveStateViaPdo(const DriveState& driveState, bool waitForState = false);
  bool lastPdoStateChangeSuccessful() const { return stateChangeSuccessful_; }

  // FoE
  bool readCalibrationResultViaFoe(CalibrationResult& calibrationResult);
  bool writeCalibrationResultViaFoe(const CalibrationResult& calibrationData);

 private:
  void engagePdoStateMachine();
  Controlword getNextStateTransitionControlword(const DriveState& requestedDriveState, const DriveState& currentDriveState);

  std::string name_;
  double timeStep_{0.0};

  mutable std::mutex stagedCommandMutex_;
  Command stagedCommand_;

  mutable std::mutex readingMutex_;
  Reading reading_;

  Configuration configuration_{};
  Controlword controlword_ = Controlword::NA;
  PdoInfo pdoInfo_;

  DriveState prevDriveState_{DriveState::NA};
  mutable std::mutex targetStateMutex_;
  DriveState targetDriveState_{DriveState::NA};
  std::atomic<bool> stateChangeSuccessful_{false};
  std::atomic<bool> conductStateChange_{false};

  std::mutex driveStateMachineSyncMutex_;  // only for blocking call to setDriveStateViaPdo
  std::condition_variable cvDriveStateMachineSync_;

  ModeOfOperation modeOfOperation_{ModeOfOperation::Disable};
};

}  // namespace foc
}  // namespace cleardrive
