//
// Created by qiayuan on 23-4-11.
//

#pragma once

#include <ecat_manager/EcatSlaveManagerBase.h>
#include <mit_ecat_slave/MitEcatSlave.h>

namespace mit_ecat {

class MitManager : public ecat_manager::EcatSlaveManagerBase<mit_ecat::MitEcatSlave> {
 public:
  using EcatSlaveManagerBase::EcatSlaveManagerBase;

  ecat_manager::EcatBusManager::EthercatSlaveType getSlaveType() const override {
    return ecat_manager::EcatBusManager::EthercatSlaveType::Mit;
  }

  // Readings
  ReadingTimePoint getReadingTime() const;  // TODO: Multiple buses
  std::vector<std::string> getMotorNames() const;
  std::vector<bool> getMotorIsOnlines() const;
  std::vector<double> getMotorPositions() const;
  std::vector<double> getMotorVelocities() const;
  std::vector<double> getMotorTorques() const;
  std::vector<bool> getDigitalInputs() const;

  // Commands
  void stageMotorCommands(const std::vector<double>& positions, const std::vector<double>& velocities, const std::vector<double>& kps,
                          const std::vector<double>& kds, const std::vector<double>& torques);
  void stageZeroCommands();
  std::vector<std::string> getDigitalOutputNames() const;
  void stageDigitalOutputs(const std::vector<bool>& outputs);

  void enableMotors() {
    for (auto& slave : slaves_) {
      slave->enableMotors();
    }
  }

  void disableMotors() {
    for (auto& slave : slaves_) {
      slave->disableMotors();
    }
  }
};

}  // namespace mit_ecat
