from cleardrive_msgs.msg import FocDriveState, FocModeOfOperation


def drive_state_to_string(drive_state):
    if drive_state == FocDriveState.STANDBY:
        return 'Standby'
    elif drive_state == FocDriveState.OPERATE:
        return 'Operate'
    elif drive_state == FocDriveState.CALIBRATE:
        return 'Calibrate'
    elif drive_state == FocDriveState.ERROR:
        return 'Error'
    elif drive_state == FocDriveState.FATAL:
        return 'Fatal'
    else:
        return 'NA'


def mode_of_operation_to_string(mode_of_operation):
    if mode_of_operation == FocModeOfOperation.DISABLE:
        return 'Disable'
    elif mode_of_operation == FocModeOfOperation.FREEZE:
        return 'Freeze'
    elif mode_of_operation == FocModeOfOperation.JOINT_TORQUE:
        return 'Torque'
    elif mode_of_operation == FocModeOfOperation.JOINT_VELOCITY:
        return 'Velocity'
    elif mode_of_operation == FocModeOfOperation.JOINT_POSITION_VELOCITY_TORQUE:
        return 'Hybrid'
    else:
        return 'NA'
