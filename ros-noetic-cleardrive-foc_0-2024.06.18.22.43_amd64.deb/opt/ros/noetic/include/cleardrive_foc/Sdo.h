//
// Created by qiayuan on 23-4-6.
//
#pragma once

namespace cleardrive {
namespace foc {

struct PidParameters {
  float kp;
  float ki;
  float kd;
};

}  // namespace foc
}  // namespace cleardrive
