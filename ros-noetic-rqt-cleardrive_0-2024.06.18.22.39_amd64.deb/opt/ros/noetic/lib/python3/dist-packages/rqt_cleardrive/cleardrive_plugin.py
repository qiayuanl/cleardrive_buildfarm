from rqt_gui_py.plugin import Plugin
from rqt_cleardrive.cleardrive import ClearDriveWidget


class ClearDrivePlugin(Plugin):

    def __init__(self, context):
        super(ClearDrivePlugin, self).__init__(context)
        self._context = context

        self._cleardrive_widget = ClearDriveWidget(self, context)
        context.add_widget(self._cleardrive_widget)
        if self._context.serial_number() > 1:
            self.mainwidget.setWindowTitle(self.mainwidget.windowTitle() + (' (%d)' % context.serial_number()))

    def shutdown_plugin(self):
        self._cleardrive_widget.shutdown()

    def save_settings(self, plugin_settings, instance_settings):
        self._cleardrive_widget.save_settings(plugin_settings, instance_settings)

    # def restore_settings(self, plugin_settings, instance_settings):
    #     self.mainwidget.restore_settings(plugin_settings, instance_settings)

    def _update_msg(self):
        """
        Update necessary components (per topic) regularly
        """
        self._cleardrive_widget.update_topic_table()
