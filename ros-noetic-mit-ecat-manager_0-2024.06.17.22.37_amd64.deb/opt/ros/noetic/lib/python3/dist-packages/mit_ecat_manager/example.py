import sys
import time

import mit_ecat_manager

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python3 example.py <config_file>")
        sys.exit(1)

    config_file = sys.argv[1]

    bus_manager = mit_ecat_manager.EcatBusManager()
    mit_manager = mit_ecat_manager.MitManager(True, True, 0.002)

    bus_manager.fromFile(config_file, True)
    mit_manager.setBusManager(bus_manager)
    mit_manager.startup()
    print(mit_manager.getMotorNames())
    while mit_manager.isRunning():
        print(mit_manager.getMotorPositions(), end='\r')
        time.sleep(0.1)
