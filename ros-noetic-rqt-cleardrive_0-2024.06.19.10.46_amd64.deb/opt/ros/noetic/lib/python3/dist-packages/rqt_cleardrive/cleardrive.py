import os
import rospy
import rospkg

from python_qt_binding import loadUi
from python_qt_binding.QtCore import QAbstractTableModel, Qt, QTimer, QVariant, Signal
from python_qt_binding.QtWidgets import QWidget, QMenu, QShortcut
from python_qt_binding.QtGui import QCursor, QFont, QIcon, QKeySequence

from cleardrive_msgs.srv import *
from cleardrive_msgs.msg import FocReadings
from rqt_cleardrive.cleardrive_foc_details import ClearDriveFocDetailsWidget

import rqt_cleardrive.cleardrive_util as util


class ClearDriveWidget(QWidget):

    def __init__(self, parent, context):
        super(ClearDriveWidget, self).__init__()
        self._context = context
        self._refresh_rate = 5  # With default value
        self._ns = '/cleardrive'

        ui_file = os.path.join(rospkg.RosPack().get_path('rqt_cleardrive'), 'resource', 'cleardrive_main.ui')
        loadUi(ui_file, self)

        # Drive State
        self._drive_state_srv = rospy.ServiceProxy(self._ns + '/set_goal_drive_state',
                                                   cleardrive_msgs.srv.SetGoalDriveState, persistent=False)
        self.button_standby.clicked.connect(self._on_standby_pressed)
        self.button_operation.clicked.connect(self._on_operation_pressed)
        self.button_error.clicked.connect(self._on_error_pressed)

        self.shortcut_ctrl_c = QShortcut(QKeySequence(Qt.CTRL + Qt.Key_C), self)
        self.shortcut_ctrl_c.setContext(Qt.ApplicationShortcut)
        self.shortcut_ctrl_c.activated.connect(self._on_standby_pressed)
        self.shortcut_ctrl_o = QShortcut(QKeySequence(Qt.CTRL + Qt.Key_O), self)
        self.shortcut_ctrl_o.setContext(Qt.ApplicationShortcut)
        self.shortcut_ctrl_o.activated.connect(self._on_operation_pressed)
        self.shortcut_space = QShortcut(QKeySequence(Qt.Key_Space), self)
        self.shortcut_space.setContext(Qt.ApplicationShortcut)
        self.shortcut_space.activated.connect(self._on_error_pressed)

        # FOC Slaves
        self._foc_readings_msg = None
        self._popup_widget = None

        self._subscriber_foc = rospy.Subscriber(self._ns + '/foc_readings', FocReadings, self._foc_callback)
        path = rospkg.RosPack().get_path('rqt_controller_manager')
        self._icons = {'NA': QIcon(path + '/resource/led_off.png'),
                       'Standby': QIcon(path + '/resource/led_off.png'),
                       'Operate': QIcon(path + '/resource/led_green.png'),
                       'Calibrate': QIcon(path + '/resource/led_green.png'),
                       'Error': QIcon(path + '/resource/led_red.png'),
                       'Fatal': QIcon(path + '/resource/led_red.png')}

        self._update_foc_timer = QTimer(self)
        self._update_foc_timer.setInterval(1000.0 / self._refresh_rate)
        self._update_foc_timer.timeout.connect(self._update_foc)
        self._update_foc_timer.start()

        self.table_foc_slaves.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table_foc_slaves.customContextMenuRequested.connect(self._on_foc_menu)

        self.table_foc_slaves.doubleClicked.connect(self._on_foc_details)

    def _on_standby_pressed(self):
        req = cleardrive_msgs.srv.SetGoalDriveStateRequest()
        req.drive_state.drive_state = cleardrive_msgs.srv.SetGoalDriveStateRequest().drive_state.STANDBY
        self._drive_state_srv.call(req)

    def _on_operation_pressed(self):
        req = cleardrive_msgs.srv.SetGoalDriveStateRequest()
        req.drive_state.drive_state = cleardrive_msgs.srv.SetGoalDriveStateRequest().drive_state.OPERATE
        self._drive_state_srv.call(req)

    def _on_error_pressed(self):
        req = cleardrive_msgs.srv.SetGoalDriveStateRequest()
        req.drive_state.drive_state = cleardrive_msgs.srv.SetGoalDriveStateRequest().drive_state.ERROR
        self._drive_state_srv.call(req)

    def _foc_callback(self, msg):
        self._foc_readings_msg = msg

    def _update_foc(self):
        if self._foc_readings_msg is None:
            return
        if self.table_foc_slaves.model() is None:
            self.table_foc_slaves.setModel(ClearFocSlavesTable(self._foc_readings_msg, self._icons))
        self.table_foc_slaves.model().update(self._foc_readings_msg)

        if self._popup_widget is not None:
            self._popup_widget.update_readings(self._foc_readings_msg)

    def _on_foc_menu(self, pos):
        # Get data of selected controller
        row = self.table_foc_slaves.rowAt(pos.y())
        if row < 0:
            return  # Cursor is not under a valid item

        name = self._foc_readings_msg.names[row]
        state = util.drive_state_to_string(self._foc_readings_msg.readings[row].drive_state.drive_state)

        menu = QMenu(self.table_foc_slaves)
        action_operate = action_standby = action_error = None
        if state == 'Standby':
            action_operate = menu.addAction(self._icons['Operate'], 'Operate')
        elif state == 'Operate':
            action_standby = menu.addAction(self._icons['Standby'], 'Standby')
            action_error = menu.addAction(self._icons['Error'], 'Error')
        elif state == 'Error':
            action_standby = menu.addAction(self._icons['Standby'], 'Standby')
        elif state == 'Fatal':
            action_standby = menu.addAction(self._icons['Standby'], 'Standby')
        else:
            return
        action = menu.exec_(QCursor.pos())
        req = cleardrive_msgs.srv.SetGoalDriveStateRequest()
        req.name = name
        if action == action_operate:
            req.drive_state.drive_state = cleardrive_msgs.srv.SetGoalDriveStateRequest().drive_state.OPERATE
        elif action == action_standby:
            req.drive_state.drive_state = cleardrive_msgs.srv.SetGoalDriveStateRequest().drive_state.STANDBY
        elif action == action_error:
            req.drive_state.drive_state = cleardrive_msgs.srv.SetGoalDriveStateRequest().drive_state.ERROR
        self._drive_state_srv.call(req)

    def _on_foc_details(self, index):
        self._popup_widget = ClearDriveFocDetailsWidget(self, self._context, index.row(), self._foc_readings_msg)
        self._popup_widget.show()

    def shutdown(self):
        self._update_foc_timer.stop()
        self._subscriber_foc.unregister()
        if self._popup_widget is not None:
            self._popup_widget.hide()

    def save_settings(self, plugin_settings, instance_settings):
        pass


class ClearFocSlavesTable(QAbstractTableModel):
    def __init__(self, msg, icons, parent=None):
        QAbstractTableModel.__init__(self, parent)
        self._msg = msg
        self._icons = icons

    def update(self, msg):
        self._msg = msg
        self.layoutChanged.emit()

    def rowCount(self, parent):
        return len(self._msg.names)

    def columnCount(self, parent):
        return 4

    def headerData(self, col, orientation, role):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            if col == 0:
                return 'Name'
            elif col == 1:
                return 'Drive State'
            elif col == 2:
                return 'Mode of Operation'
            elif col == 3:
                return 'Temperature'
        else:
            return None

    def data(self, index, role):
        if not index.isValid():
            return None
        name = self._msg.names[index.row()]
        reading = self._msg.readings[index.row()]

        if role == Qt.DisplayRole:
            if index.column() == 0:
                return name
            elif index.column() == 1:
                return util.drive_state_to_string(reading.drive_state.drive_state)
            elif index.column() == 2:
                return util.mode_of_operation_to_string(reading.mode_of_operation.mode_of_operation)
            elif index.column() == 3:
                return "{:.1f}".format(reading.temperature)

        if role == Qt.DecorationRole:
            if index.column() == 0:
                return self._icons[util.drive_state_to_string(reading.drive_state.drive_state)]

        if role == Qt.FontRole:
            if index.column() == 0:
                bf = QFont()
                bf.setBold(True)
                return bf
