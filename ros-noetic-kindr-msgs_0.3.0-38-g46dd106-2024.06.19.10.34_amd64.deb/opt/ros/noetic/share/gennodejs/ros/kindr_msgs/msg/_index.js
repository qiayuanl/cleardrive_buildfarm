
"use strict";

let VectorAtPosition = require('./VectorAtPosition.js');

module.exports = {
  VectorAtPosition: VectorAtPosition,
};
