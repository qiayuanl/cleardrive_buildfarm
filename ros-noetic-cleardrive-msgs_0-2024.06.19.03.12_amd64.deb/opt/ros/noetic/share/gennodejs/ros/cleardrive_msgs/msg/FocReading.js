// Auto-generated. Do not edit!

// (in-package cleardrive_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let FocDriveState = require('./FocDriveState.js');
let FocModeOfOperation = require('./FocModeOfOperation.js');

//-----------------------------------------------------------

class FocReading {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.drive_state = null;
      this.mode_of_operation = null;
      this.statusword = null;
      this.joint_position = null;
      this.joint_velocity = null;
      this.joint_torque = null;
      this.voltage = null;
      this.temperature = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('drive_state')) {
        this.drive_state = initObj.drive_state
      }
      else {
        this.drive_state = new FocDriveState();
      }
      if (initObj.hasOwnProperty('mode_of_operation')) {
        this.mode_of_operation = initObj.mode_of_operation
      }
      else {
        this.mode_of_operation = new FocModeOfOperation();
      }
      if (initObj.hasOwnProperty('statusword')) {
        this.statusword = initObj.statusword
      }
      else {
        this.statusword = 0;
      }
      if (initObj.hasOwnProperty('joint_position')) {
        this.joint_position = initObj.joint_position
      }
      else {
        this.joint_position = 0.0;
      }
      if (initObj.hasOwnProperty('joint_velocity')) {
        this.joint_velocity = initObj.joint_velocity
      }
      else {
        this.joint_velocity = 0.0;
      }
      if (initObj.hasOwnProperty('joint_torque')) {
        this.joint_torque = initObj.joint_torque
      }
      else {
        this.joint_torque = 0.0;
      }
      if (initObj.hasOwnProperty('voltage')) {
        this.voltage = initObj.voltage
      }
      else {
        this.voltage = 0.0;
      }
      if (initObj.hasOwnProperty('temperature')) {
        this.temperature = initObj.temperature
      }
      else {
        this.temperature = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FocReading
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [drive_state]
    bufferOffset = FocDriveState.serialize(obj.drive_state, buffer, bufferOffset);
    // Serialize message field [mode_of_operation]
    bufferOffset = FocModeOfOperation.serialize(obj.mode_of_operation, buffer, bufferOffset);
    // Serialize message field [statusword]
    bufferOffset = _serializer.uint32(obj.statusword, buffer, bufferOffset);
    // Serialize message field [joint_position]
    bufferOffset = _serializer.float64(obj.joint_position, buffer, bufferOffset);
    // Serialize message field [joint_velocity]
    bufferOffset = _serializer.float64(obj.joint_velocity, buffer, bufferOffset);
    // Serialize message field [joint_torque]
    bufferOffset = _serializer.float64(obj.joint_torque, buffer, bufferOffset);
    // Serialize message field [voltage]
    bufferOffset = _serializer.float32(obj.voltage, buffer, bufferOffset);
    // Serialize message field [temperature]
    bufferOffset = _serializer.float32(obj.temperature, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FocReading
    let len;
    let data = new FocReading(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [drive_state]
    data.drive_state = FocDriveState.deserialize(buffer, bufferOffset);
    // Deserialize message field [mode_of_operation]
    data.mode_of_operation = FocModeOfOperation.deserialize(buffer, bufferOffset);
    // Deserialize message field [statusword]
    data.statusword = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [joint_position]
    data.joint_position = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [joint_velocity]
    data.joint_velocity = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [joint_torque]
    data.joint_torque = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [voltage]
    data.voltage = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [temperature]
    data.temperature = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 46;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cleardrive_msgs/FocReading';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd935b6a70f30406aff92088d10da17c0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp
    
    FocDriveState  drive_state
    FocModeOfOperation mode_of_operation
    uint32 statusword
    
    float64 joint_position
    float64 joint_velocity
    float64 joint_torque
    
    float32 voltage
    float32 temperature
    
    ================================================================================
    MSG: cleardrive_msgs/FocDriveState
    uint8 START = 1
    uint8 STANDBY = 2
    uint8 OPERATE = 3
    uint8 CALIBRATE = 4
    uint8 ERROR = 5
    uint8 FATAL = 6
    
    uint8 drive_state
    
    ================================================================================
    MSG: cleardrive_msgs/FocModeOfOperation
    uint8 DISABLE = 1
    uint8 FREEZE = 2
    uint8 JOINT_TORQUE = 3
    uint8 JOINT_VELOCITY = 4
    uint8 JOINT_POSITION_VELOCITY_TORQUE = 5
    
    uint8 mode_of_operation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FocReading(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.drive_state !== undefined) {
      resolved.drive_state = FocDriveState.Resolve(msg.drive_state)
    }
    else {
      resolved.drive_state = new FocDriveState()
    }

    if (msg.mode_of_operation !== undefined) {
      resolved.mode_of_operation = FocModeOfOperation.Resolve(msg.mode_of_operation)
    }
    else {
      resolved.mode_of_operation = new FocModeOfOperation()
    }

    if (msg.statusword !== undefined) {
      resolved.statusword = msg.statusword;
    }
    else {
      resolved.statusword = 0
    }

    if (msg.joint_position !== undefined) {
      resolved.joint_position = msg.joint_position;
    }
    else {
      resolved.joint_position = 0.0
    }

    if (msg.joint_velocity !== undefined) {
      resolved.joint_velocity = msg.joint_velocity;
    }
    else {
      resolved.joint_velocity = 0.0
    }

    if (msg.joint_torque !== undefined) {
      resolved.joint_torque = msg.joint_torque;
    }
    else {
      resolved.joint_torque = 0.0
    }

    if (msg.voltage !== undefined) {
      resolved.voltage = msg.voltage;
    }
    else {
      resolved.voltage = 0.0
    }

    if (msg.temperature !== undefined) {
      resolved.temperature = msg.temperature;
    }
    else {
      resolved.temperature = 0.0
    }

    return resolved;
    }
};

module.exports = FocReading;
