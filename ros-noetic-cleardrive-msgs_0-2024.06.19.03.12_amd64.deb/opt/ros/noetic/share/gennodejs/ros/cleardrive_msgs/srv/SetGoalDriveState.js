// Auto-generated. Do not edit!

// (in-package cleardrive_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let FocDriveState = require('../msg/FocDriveState.js');
let FocModeOfCalibration = require('../msg/FocModeOfCalibration.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetGoalDriveStateRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.drive_state = null;
      this.mode_of_calibration = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('drive_state')) {
        this.drive_state = initObj.drive_state
      }
      else {
        this.drive_state = new FocDriveState();
      }
      if (initObj.hasOwnProperty('mode_of_calibration')) {
        this.mode_of_calibration = initObj.mode_of_calibration
      }
      else {
        this.mode_of_calibration = new FocModeOfCalibration();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetGoalDriveStateRequest
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [drive_state]
    bufferOffset = FocDriveState.serialize(obj.drive_state, buffer, bufferOffset);
    // Serialize message field [mode_of_calibration]
    bufferOffset = FocModeOfCalibration.serialize(obj.mode_of_calibration, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetGoalDriveStateRequest
    let len;
    let data = new SetGoalDriveStateRequest(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [drive_state]
    data.drive_state = FocDriveState.deserialize(buffer, bufferOffset);
    // Deserialize message field [mode_of_calibration]
    data.mode_of_calibration = FocModeOfCalibration.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    return length + 6;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cleardrive_msgs/SetGoalDriveStateRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'de30c8ee0b6153732888b5ad5a860f2e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name
    FocDriveState drive_state
    FocModeOfCalibration mode_of_calibration
    
    
    ================================================================================
    MSG: cleardrive_msgs/FocDriveState
    uint8 START = 1
    uint8 STANDBY = 2
    uint8 OPERATE = 3
    uint8 CALIBRATE = 4
    uint8 ERROR = 5
    uint8 FATAL = 6
    
    uint8 drive_state
    
    ================================================================================
    MSG: cleardrive_msgs/FocModeOfCalibration
    uint8  PHASES = 0
    uint8  OFFSET_PHI_E = 1
    uint8  DIRECTION_JOINT = 2
    uint8  OFFSET_JOINT = 3
    uint8  IC_MU = 4
    uint8  IC_MU_LUT = 5
    
    uint8 mode_of_calibration
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetGoalDriveStateRequest(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.drive_state !== undefined) {
      resolved.drive_state = FocDriveState.Resolve(msg.drive_state)
    }
    else {
      resolved.drive_state = new FocDriveState()
    }

    if (msg.mode_of_calibration !== undefined) {
      resolved.mode_of_calibration = FocModeOfCalibration.Resolve(msg.mode_of_calibration)
    }
    else {
      resolved.mode_of_calibration = new FocModeOfCalibration()
    }

    return resolved;
    }
};

class SetGoalDriveStateResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_success = null;
    }
    else {
      if (initObj.hasOwnProperty('is_success')) {
        this.is_success = initObj.is_success
      }
      else {
        this.is_success = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetGoalDriveStateResponse
    // Serialize message field [is_success]
    bufferOffset = _serializer.bool(obj.is_success, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetGoalDriveStateResponse
    let len;
    let data = new SetGoalDriveStateResponse(null);
    // Deserialize message field [is_success]
    data.is_success = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cleardrive_msgs/SetGoalDriveStateResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fa3e942e5cfe76a6a46f20a0780b2cf3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool is_success
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetGoalDriveStateResponse(null);
    if (msg.is_success !== undefined) {
      resolved.is_success = msg.is_success;
    }
    else {
      resolved.is_success = false
    }

    return resolved;
    }
};

module.exports = {
  Request: SetGoalDriveStateRequest,
  Response: SetGoalDriveStateResponse,
  md5sum() { return 'fc9621931903743aa7a6936d7df5f0ae'; },
  datatype() { return 'cleardrive_msgs/SetGoalDriveState'; }
};
