
"use strict";

let RmSlaveReading = require('./RmSlaveReading.js');
let RmSlaveReadings = require('./RmSlaveReadings.js');

module.exports = {
  RmSlaveReading: RmSlaveReading,
  RmSlaveReadings: RmSlaveReadings,
};
