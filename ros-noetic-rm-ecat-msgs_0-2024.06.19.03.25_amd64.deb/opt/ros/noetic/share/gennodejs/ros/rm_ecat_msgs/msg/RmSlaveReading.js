// Auto-generated. Do not edit!

// (in-package rm_ecat_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RmSlaveReading {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.statusword = null;
      this.names = null;
      this.isOnline = null;
      this.isOverTemperature = null;
      this.position = null;
      this.velocity = null;
      this.torque = null;
      this.temperature = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('statusword')) {
        this.statusword = initObj.statusword
      }
      else {
        this.statusword = 0;
      }
      if (initObj.hasOwnProperty('names')) {
        this.names = initObj.names
      }
      else {
        this.names = [];
      }
      if (initObj.hasOwnProperty('isOnline')) {
        this.isOnline = initObj.isOnline
      }
      else {
        this.isOnline = [];
      }
      if (initObj.hasOwnProperty('isOverTemperature')) {
        this.isOverTemperature = initObj.isOverTemperature
      }
      else {
        this.isOverTemperature = [];
      }
      if (initObj.hasOwnProperty('position')) {
        this.position = initObj.position
      }
      else {
        this.position = [];
      }
      if (initObj.hasOwnProperty('velocity')) {
        this.velocity = initObj.velocity
      }
      else {
        this.velocity = [];
      }
      if (initObj.hasOwnProperty('torque')) {
        this.torque = initObj.torque
      }
      else {
        this.torque = [];
      }
      if (initObj.hasOwnProperty('temperature')) {
        this.temperature = initObj.temperature
      }
      else {
        this.temperature = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RmSlaveReading
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [statusword]
    bufferOffset = _serializer.uint32(obj.statusword, buffer, bufferOffset);
    // Serialize message field [names]
    bufferOffset = _arraySerializer.string(obj.names, buffer, bufferOffset, null);
    // Serialize message field [isOnline]
    bufferOffset = _arraySerializer.bool(obj.isOnline, buffer, bufferOffset, null);
    // Serialize message field [isOverTemperature]
    bufferOffset = _arraySerializer.bool(obj.isOverTemperature, buffer, bufferOffset, null);
    // Serialize message field [position]
    bufferOffset = _arraySerializer.float64(obj.position, buffer, bufferOffset, null);
    // Serialize message field [velocity]
    bufferOffset = _arraySerializer.float64(obj.velocity, buffer, bufferOffset, null);
    // Serialize message field [torque]
    bufferOffset = _arraySerializer.float64(obj.torque, buffer, bufferOffset, null);
    // Serialize message field [temperature]
    bufferOffset = _arraySerializer.float64(obj.temperature, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RmSlaveReading
    let len;
    let data = new RmSlaveReading(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [statusword]
    data.statusword = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [names]
    data.names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [isOnline]
    data.isOnline = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [isOverTemperature]
    data.isOverTemperature = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [position]
    data.position = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [velocity]
    data.velocity = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [torque]
    data.torque = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [temperature]
    data.temperature = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.names.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += object.isOnline.length;
    length += object.isOverTemperature.length;
    length += 8 * object.position.length;
    length += 8 * object.velocity.length;
    length += 8 * object.torque.length;
    length += 8 * object.temperature.length;
    return length + 40;
  }

  static datatype() {
    // Returns string type for a message object
    return 'rm_ecat_msgs/RmSlaveReading';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9052078c39407bd62188a69a51c33bbd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp
    
    uint32 statusword
    
    string[] names
    bool[] isOnline
    bool[] isOverTemperature
    
    float64[] position
    float64[] velocity
    float64[] torque
    float64[] temperature
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RmSlaveReading(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.statusword !== undefined) {
      resolved.statusword = msg.statusword;
    }
    else {
      resolved.statusword = 0
    }

    if (msg.names !== undefined) {
      resolved.names = msg.names;
    }
    else {
      resolved.names = []
    }

    if (msg.isOnline !== undefined) {
      resolved.isOnline = msg.isOnline;
    }
    else {
      resolved.isOnline = []
    }

    if (msg.isOverTemperature !== undefined) {
      resolved.isOverTemperature = msg.isOverTemperature;
    }
    else {
      resolved.isOverTemperature = []
    }

    if (msg.position !== undefined) {
      resolved.position = msg.position;
    }
    else {
      resolved.position = []
    }

    if (msg.velocity !== undefined) {
      resolved.velocity = msg.velocity;
    }
    else {
      resolved.velocity = []
    }

    if (msg.torque !== undefined) {
      resolved.torque = msg.torque;
    }
    else {
      resolved.torque = []
    }

    if (msg.temperature !== undefined) {
      resolved.temperature = msg.temperature;
    }
    else {
      resolved.temperature = []
    }

    return resolved;
    }
};

module.exports = RmSlaveReading;
