//
// Created by qiayuan on 23-4-10.
//

#pragma once

#include <fstream>
#include <soem_interface_rsl/EthercatBusManagerBase.hpp>

namespace ecat_manager {
class EcatBusManager : public soem_interface_rsl::EthercatBusManagerBase {
 public:
  using SharedPtr = std::shared_ptr<EcatBusManager>;

  enum class EthercatSlaveType { ClearFoc, ClearImu, Mit, Rm, NA };

  struct EthercatSlaveEntry {
    EthercatSlaveType type;
    std::string name;
    std::string configFilePath;

    uint32_t ethercatAddress;
    std::string ethercatBus;
  };

  bool fromFile(const std::string& file, bool startup);

  const EthercatSlaveEntry& getInfoForSlave(const std::shared_ptr<soem_interface_rsl::EthercatSlaveBase>& slave);

  template <typename T, typename dummy = std::enable_if_t<std::is_base_of_v<soem_interface_rsl::EthercatSlaveBase, T>>>
  std::vector<std::shared_ptr<T>> getSlavesOfType(EthercatSlaveType ethercatSlaveType) {
    std::vector<std::shared_ptr<T>> slaves;

    for (auto& slave : slaves_) {
      if (getInfoForSlave(slave).type == ethercatSlaveType) {
        auto ptr = std::dynamic_pointer_cast<T>(slave);
        if (ptr) {
          slaves.push_back(ptr);
        } else {
          throw std::runtime_error("getSlavesOfType: ethercatSlaveTyp and provided Type does not match!");
        }
      }
    }
    return slaves;
  }

 protected:
  void parseFile(std::string path);

  void setup(bool startup);

  static std::string handleFilePath(const std::string& path, const std::string& setup_file_path);

  std::vector<std::shared_ptr<soem_interface_rsl::EthercatSlaveBase>> slaves_;

  std::vector<EthercatSlaveEntry> slaveEntries_;
  std::map<std::shared_ptr<soem_interface_rsl::EthercatSlaveBase>, EthercatSlaveEntry> slave2Entry_;

  std::string setupFilepath_;
  double timeStep_ = 0.0;
};

}  // namespace ecat_manager
