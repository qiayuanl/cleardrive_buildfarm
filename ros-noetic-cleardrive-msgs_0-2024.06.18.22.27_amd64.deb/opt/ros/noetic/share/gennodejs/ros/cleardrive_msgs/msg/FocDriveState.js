// Auto-generated. Do not edit!

// (in-package cleardrive_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FocDriveState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.drive_state = null;
    }
    else {
      if (initObj.hasOwnProperty('drive_state')) {
        this.drive_state = initObj.drive_state
      }
      else {
        this.drive_state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FocDriveState
    // Serialize message field [drive_state]
    bufferOffset = _serializer.uint8(obj.drive_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FocDriveState
    let len;
    let data = new FocDriveState(null);
    // Deserialize message field [drive_state]
    data.drive_state = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cleardrive_msgs/FocDriveState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '17d7c6a697e941bafc4a12d02aeaf9d9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 START = 1
    uint8 STANDBY = 2
    uint8 OPERATE = 3
    uint8 CALIBRATE = 4
    uint8 ERROR = 5
    uint8 FATAL = 6
    
    uint8 drive_state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FocDriveState(null);
    if (msg.drive_state !== undefined) {
      resolved.drive_state = msg.drive_state;
    }
    else {
      resolved.drive_state = 0
    }

    return resolved;
    }
};

// Constants for message
FocDriveState.Constants = {
  START: 1,
  STANDBY: 2,
  OPERATE: 3,
  CALIBRATE: 4,
  ERROR: 5,
  FATAL: 6,
}

module.exports = FocDriveState;
