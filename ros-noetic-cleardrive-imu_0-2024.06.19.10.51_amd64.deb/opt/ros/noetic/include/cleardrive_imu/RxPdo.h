#pragma once

#include <cstdint>

namespace cleardrive {
namespace imu {

struct RxPdo {
  uint8_t controlword_;

} __attribute__((packed));

}  // namespace imu

}  // namespace cleardrive
