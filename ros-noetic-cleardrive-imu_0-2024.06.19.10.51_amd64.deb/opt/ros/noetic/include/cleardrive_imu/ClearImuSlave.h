//
// Created by qiayuan on 23-3-12.
//

#pragma once

#include "cleardrive_imu/Configuration.h"
#include "cleardrive_imu/Controlword.h"
#include "cleardrive_imu/Reading.h"
#include "cleardrive_imu/Sdo.h"

#include <soem_interface_rsl/EthercatSlaveBase.hpp>

#include <yaml-cpp/yaml.h>

#include <condition_variable>

namespace cleardrive {
namespace imu {

class ClearImuSlave : public soem_interface_rsl::EthercatSlaveBase {
 public:
  using SharedPtr = std::shared_ptr<ClearImuSlave>;
  void setTimeStep(double timeStep) { timeStep_ = timeStep; }
  void setState(soem_interface_rsl::ETHERCAT_SM_STATE state);
  bool waitForState(soem_interface_rsl::ETHERCAT_SM_STATE state, unsigned int maxRetries = 40);

  static SharedPtr deviceFromFile(const std::string& configFile, const std::string& name, uint32_t address);

  // Constructor
  ClearImuSlave() = default;
  ClearImuSlave(const std::string& name, uint32_t address);

  // pure virtual overwrites
  std::string getName() const override { return name_; }
  bool startup() override;
  void shutdown() override;
  void updateWrite() override;
  void updateRead() override;
  PdoInfo getCurrentPdoInfo() const override { return pdoInfo_; }

  // Control
  void stageDisableHeat();
  void stageEnableHeat();

  // Readings
  Reading getReading() const;
  void getReading(Reading& reading) const;

  // Configuration
  bool loadConfigFile(const std::string& fileName);
  bool loadConfigNode(const YAML::Node& configNode);
  bool loadConfiguration(const Configuration& configuration);
  Configuration getConfiguration() const;

  // SDO
  bool getStatuswordViaSdo(Statusword& statusword);
  bool setDesiredTemperatureViaSdo(uint8_t temp);
  bool setSampleRateViaSdo(uint8_t sampleRate);
  bool setPidParametersViaSdo(float kp, float ki, float kd, float maxOut, float maxIOut);

 private:
  std::string name_;
  double timeStep_{0.0};

  mutable std::mutex stagedCommandMutex_;
  mutable std::mutex readingMutex_;
  Reading reading_;

  Configuration configuration_{};
  Controlword controlword_{};
  PdoInfo pdoInfo_;
};

}  // namespace imu
}  // namespace cleardrive
