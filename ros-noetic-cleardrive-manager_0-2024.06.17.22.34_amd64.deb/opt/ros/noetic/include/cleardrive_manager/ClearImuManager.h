//
// Created by qiayuan on 23-4-11.
//

#pragma once

#include <cleardrive_imu/ClearImuSlave.h>
#include <ecat_manager/EcatSlaveManagerBase.h>

namespace cleardrive::imu {

class ClearImuManager : public ecat_manager::EcatSlaveManagerBase<ClearImuSlave> {
 public:
  // Setup and configuration
  using EcatSlaveManagerBase::EcatSlaveManagerBase;
  ecat_manager::EcatBusManager::EthercatSlaveType getSlaveType() const override {
    return ecat_manager::EcatBusManager::EthercatSlaveType::ClearImu;
  }

  // Control
  void stageDisableHeats();
  void stageEnablesHeats();
};

}  // namespace cleardrive::imu
