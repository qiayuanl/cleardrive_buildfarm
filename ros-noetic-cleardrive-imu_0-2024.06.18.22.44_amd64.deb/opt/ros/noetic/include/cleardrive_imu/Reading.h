//
// Created by qiayuan on 23-3-14.
//

#pragma once

#include <chrono>
#include <string>

#include "cleardrive_imu/Statusword.h"

namespace cleardrive {
namespace imu {

using ReadingTimePoint = std::chrono::time_point<std::chrono::high_resolution_clock>;

class Reading {
 public:
  const ReadingTimePoint& getStamp() const { return stamp_; }
  void setStamp(const ReadingTimePoint& stamp) { stamp_ = stamp; }
  const Statusword& getStatusword() const { return statusword_; }
  void setStatusword(const Statusword& statusword) { statusword_ = statusword; }

  void setTemperature(const float temperature) { temperature_ = temperature; }
  float getTemperature() const { return temperature_; }
  void setOrientation(float w, float x, float y, float z);
  const float* getOrientation() const { return orientation_; }
  void setLinearAcceleration(float x, float y, float z);
  const float* getLinearAcceleration() const { return linearAcceleration_; }
  void setAngularVelocity(float x, float y, float z);
  const float* getAngularVelocity() const { return angularVelocity_; }

  //  bool isValid() const;
  //
  //  virtual std::string asString(const std::string& prefix = "") const;

 protected:
  ReadingTimePoint stamp_;
  Statusword statusword_;

  float temperature_;
  float orientation_[4];
  float linearAcceleration_[3];
  float angularVelocity_[3];
};

}  // namespace imu
}  // namespace cleardrive
